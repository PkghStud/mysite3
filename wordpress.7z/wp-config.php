<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'mysite3' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '123' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'GHQ[iXA@}l[NEB;VJ/;JT,y?py4`(O*(41+^FikRhTSV8~LMVzvw6a^/B0iMz[Ka' );
define( 'SECURE_AUTH_KEY',  'Gz< FGs,o+xh5fdk8,4=<$O8wW8yLhyhe~195!{VBO^$gy~V~Q4xab.H-SgLf?wy' );
define( 'LOGGED_IN_KEY',    'bTQ=j~,OLR4EM!RD93Ryyu?lPfxj=j0k?PJ<8s|.f|]eqv+^r3#B0g0ps-8PQzrL' );
define( 'NONCE_KEY',        't@[(3()%a)r!6>O8Y E@*Fa^pfYI3$#99%diFNim}]Ja&@`HRZ1pF%3P5r,kK0f?' );
define( 'AUTH_SALT',        '{|n0T&6HW]mY#;)]vLFavuTcg$@yMXTO:]}/GvQ)yuKxN8p6}+Xxkt+shZpn]J>?' );
define( 'SECURE_AUTH_SALT', 'TlhAn{7I;Oe }!Odn;{)*Z6jnG^k04WEL4~_%TkN:W:gwqKGfQl1L5&#0D6aD 9U' );
define( 'LOGGED_IN_SALT',   '2!M19fG{FHxfd]x;A)S)Q+qq#4.EkmQqR!Jwr1RYVkDj,vL9cx)(x5e=kzVZf7xG' );
define( 'NONCE_SALT',       'HQKNDn*Dw2JTJqB.)bP~[Su$?z9;#5S*m[&aEfUOQ2OS7U!%pWe ^&fN4ehQXmPi' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
